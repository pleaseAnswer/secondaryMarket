var customer = {
    firstName: 'Tom',
    lastName: 'Hanks',
    sayHi: function () { return 'Hi there'; }
};
console.log('Customer 对象 ');
console.log(customer.firstName);
console.log(customer.lastName);
console.log(customer.sayHi());
var employee = {
    firstName: 'Zhou',
    lastName: 'yaoyao',
    sayHi: function () { return 'Hello!!'; }
};
console.log('Employee 对象 ');
console.log(employee.firstName);
console.log(employee.lastName);
console.log(employee.sayHi());
